package util;

import java.io.File;

public class StringUtils {

	// Start SQL Queries
	public static final String INSERT_CUSTOMER = "INSERT INTO `users` "
			+ "(UserName, Email, Password, Address, PhoneNumber, Role) " + "VALUES (?, ?, ?, ?, ?, ?)";

	public static final String INSERT_PRODUCT = "INSERT INTO `product` "
			+ "(ProductName, Description, ProductPrice, StockQuantity, Brand, Image,Processor,RAM,GraphicCard,OperatingSystem,Color) "
			+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	public static final String GET_USER_BY_USERNAME = "SELECT UserId FROM users WHERE username = ?";

	public static final String GET_LOGIN_USER_INFO = "SELECT * FROM users WHERE UserName = ?";
	public static final String GET_USERNAME = "SELECT COUNT(*) FROM student_info WHERE user_name = ?";
	public static final String GET_PHONE = "SELECT COUNT(*) FROM student_info WHERE phone_number = ?";
	public static final String GET_EMAIL = "SELECT COUNT(*) FROM student_info WHERE email = ?";
	public static final String GET_ALL_PRODUCTS = "SELECT * FROM product";
	public static final String GET_product_name = "SELECT * FROM product WHERE ProductName = ?";
	public static final String DELETE_PRODUCT = "DELETE FROM product WHERE ProductName = ?";
	// End SQL Queries

	// Start Parameter names
	public static final String USER_NAME = "userName";
	public static final String EMAIL = "email";
	public static final String PHONE_NUMBER = "phoneNumber";
	public static final String PASSWORD = "password";
	public static final String ADDRESS = "address";
	public static final String RETYPE_PASSWORD = "retypePassword";

	public static final String PRODUCT_NAME = "product_name";
	public static final String BRAND = "brand";
	public static final String DESCRIPTION = "description";
	public static final String PRICE = "price";
	public static final String QUANTITY = "quantity";
	public static final String IMAGE = "image_url";
	public static final String PROCESSOR = "processor";
	public static final String RAM = "ram";
	public static final String GRAPHIC_CARD = "graphic_card";
	public static final String OPERATING_SYSTEM = "os";
	public static final String COLOR = "color";
	// End Parameter names

	// Start string messages
	// Start register page messages
	public static final String SUCCESS_REGISTER_MESSAGE = "Successfully Registered!";
	public static final String ERROR_REGISTER_MESSAGE = "Please correct the form data.";
	public static final String SERVER_ERROR_MESSAGE = "An unexpected server error occurred.";
	public static final String USERNAME_ERROR_MESSAGE = "Username is already registered.";
	public static final String EMAIL_ERROR_MESSAGE = "Email is already registered.";
	public static final String PHONE_NUMBER_ERROR_MESSAGE = "Phone Number is already registered.";
	public static final String PASSWORD_UNMATCHED_ERROR_MESSAGE = "Password not matched.";
	// End register page messages

	// Start login page message
	public static final String SUCCESS_LOGIN_MESSAGE = "Successfully LoggedIn!";
	public static final String ERROR_LOGIN_MESSAGE = "Either username or password is not correct!";
	// End login page message

	public static final String SUCCESS_MESSAGE = "successMessage";
	public static final String ERROR_MESSAGE = "errorMessage";
	// End string messages

	// Start JSP Route
	public static final String LOGIN_PAGE = "/pages/login.jsp";
	public static final String REGISTER_PAGE = "/pages/register.jsp";
	public static final String WELCOME_PAGE = "/pages/home.jsp";
	public static final String ADMIN_DASHBOARD_PAGE = "/pages/adminDash.jsp";
	// End JSP Route

	// image Directories
	public static final String SAVE_PATH = "/home/arch/eclipse-workspace/LapBuy/src/main/webapp/Downloads";
	public static final String IMAGE_DIR = "Users\\Legion\\eclipse-workspace\\LapBuy\\src\\main\\webapp\\Downloads\\";
	public static final String IMAGE_DIR_PATH = "C:" + File.separator + IMAGE_DIR;
	// Start Servlet Route
	public static final String REGISTER_SERVLET = "/RegisterServlet";
	public static final String LOGIN_SERVLET = "/LoginServlet";
	public static final String PRODUCT_SERVLET = "/ProductServlet";
	public static final String PRODUCT_DISPLAY_SERVLET = "/ProductDisplayServlet";
	public static final String ADMIN_PRODUCT_DISPLAY_SERVLET = "/AdminProductDisplayServlet";
	// End Servlet Route

//	cart query
	public static final String ADD_TO_CART = "INSERT INTO CARTS " + "(product_Id, user_Id, quantity) "
			+ "VALUES (?,?,?)";

	public static final String INSERT_TO_CART = "INSERT INTO cart " + "(Quantity, AddedDate, UserId, ProductId) "
			+ "VALUES (?, NOW(), ?, ?)";

	public static final String SELECT_CART = "SELECT * FROM CARTS";
	public static final String DELETE_CART = "delete from carts where cart_Id=?";
	public static final String get_cart_product_details = "SELECT cart1.CartId, cart.Quantity, cart.AddedDate, users.UserId, product.ProductId FROM cart "
			+ "INNER JOIN users ON cart.UserId = users.UserId "
			+ "INNER JOIN product ON cart.ProductId = product.ProductIdb WHERE cart.UserId=?";
	public static final String UPDATE_PRODUCT_DETAILS = "UPDATE products SET "
			+ " product_Name = ?, product_Description = ?, product_Price = ?, product_Company = ?, "
			+ " product_Stock = ?, product_Image = ?,  product_Color = ?, product_Type = ?,  product_Capacity = ? "
			+ "WHERE product_Id = ?";

	public static final String CART_PAGE = "/cartServlet";

}
