package model;

import java.util.Date;

public class CartModel {
		private String ProductId;
	    private int UserId;
	    private String CartId;
	    private int Quantity;

    public CartModel() {
        super();
    }

    public CartModel(String ProductId, int UserId, int Quantity ) {
		super();
		this.ProductId = ProductId;
		this.UserId = UserId;
		this.Quantity = Quantity;
	}
    // Getters and setters
    public String getCartId() {
		return CartId;
	}

	public void setCartId(String CartId) {
		this.CartId = CartId;
	}
    
    public String getProductId() {
        return ProductId;
    }

	public void setProductId(String ProductId) {
        this.ProductId = ProductId;
    }

    public int getUserId() {
        return UserId;
    }

    public void setUserId(int UserId) {
        this.UserId = UserId;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        this.Quantity = quantity;
    }
}