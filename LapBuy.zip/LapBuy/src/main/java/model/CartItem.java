package model;

import java.sql.Timestamp;

public class CartItem {
	// Getters and setters
	private int ProductId;
	private String ProductName;
	private int UserId;
	private int CartId;
	private int Quantity;
	private int ProductPrice;
	private Timestamp AddedDate; // Change to java.sql.Timestamp

	// Constructor
	public CartItem(int productId, String productName, int userId, int cartId, int quantity, int ProductPrice,
			Timestamp addedDate) {
		super();
		this.ProductId = productId;
		this.ProductName = productName;
		this.UserId = userId;
		this.CartId = cartId;
		this.Quantity = quantity;
		this.ProductPrice = ProductPrice;
		this.AddedDate = addedDate;
	}

	public int getProductId() {
		return ProductId;
	}

	public void setProductId(int productId) {
		this.ProductId = productId;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		this.ProductName = productName;
	}

	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		this.UserId = userId;
	}

	public int getCartId() {
		return CartId;
	}

	public void setCartId(int cartId) {
		this.CartId = cartId;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		this.Quantity = quantity;
	}

	public int getProductPrice() {
		return ProductPrice;
	}

	public void setProductPrice(int ProductPrice) {
		this.ProductPrice = ProductPrice;
	}

	public Timestamp getAddedDate() {
		return AddedDate;
	}

	public void setAddedDate(Timestamp addedDate) {
		this.AddedDate = addedDate;
	}

}
