package model;


import java.io.File;

import javax.servlet.http.Part;

import com.mysql.cj.util.StringUtils;

public class ProductModel {
    private int productId;
    private String productName;
    private String description;
    private int productPrice; 
    private int stockQuantity;
    private String brand;
    private String image;
    private String processor;
    private String ram;
    private String graphicCard;
    private String operatingSystem;
    private String color;

    // Constructor with parameters
    public ProductModel(int productId, String productName, String description, int productPrice, int stockQuantity,
                        String brand,Part image, String processor, String ram, String graphicCard,
                        String operatingSystem, String color) {
      
        this.productName = productName;
        this.description = description;
        this.productPrice = productPrice;
        this.productId = productId;
        this.stockQuantity = stockQuantity;
        this.brand = brand;
        this.image = this.getImageString(image);
        this.processor = processor;
        this.ram = ram;
        this.graphicCard = graphicCard;
        this.operatingSystem = operatingSystem;
        this.color = color;
        
        
    }
    public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	private String getImageString(Part imagePart) {
		String savePath = util.StringUtils.SAVE_PATH;
		File fileSaveDir = new File(savePath);
		String imageUrlFromPart = null;
		if (imagePart == null){
			return null;
		}
		if (!fileSaveDir.exists()) {
			fileSaveDir.mkdir();
		}
		String contentDisp = imagePart.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				imageUrlFromPart = s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		if (imageUrlFromPart == null || imageUrlFromPart.isEmpty()) {
			return "a";
		}
		return imageUrlFromPart;
	}
    // Default constructor
    public ProductModel() {
        // Default constructor
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(int productPrice) {
        this.productPrice = productPrice;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(int stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getProcessor() {
        return processor;
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public String getGraphicCard() {
        return graphicCard;
    }

    public void setGraphicCard(String graphicCard) {
        this.graphicCard = graphicCard;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
