package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.CartItem;
import model.CartModel;
import model.PasswordEncryptionWIthAes;
import model.ProductModel;
import model.UserModel;
import util.StringUtils;

public class DatabaseController {
	private static final String DB_URL = "jdbc:mysql://localhost:3306/lapbuy";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "";

	public static Connection getConnection() throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
	}

	public int addUser(UserModel userModel) {
		try (Connection con = getConnection();
				PreparedStatement st = con.prepareStatement(StringUtils.INSERT_CUSTOMER)) {

			String encryptedPassword = PasswordEncryptionWIthAes.encryptPassword(userModel.getPassword(),
					"U3CdwubLD5yQbUOG92ZnHw==");

			st.setString(1, userModel.getUserName());
			st.setString(2, userModel.getEmail());
			st.setString(3, encryptedPassword);
			st.setString(4, userModel.getAddress());
			st.setString(5, userModel.getPhoneNumber());
			st.setString(6, userModel.getRole());

			return st.executeUpdate();

		} catch (SQLException ex) {
			ex.printStackTrace();
			return -1;
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
			return -1;
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		}
	}

	public int getUserLoginInfo(String userName, String password) {
		try (Connection con = getConnection();
				PreparedStatement st = con.prepareStatement(StringUtils.GET_LOGIN_USER_INFO)) {

			st.setString(1, userName);

			try (ResultSet rs = st.executeQuery()) {
				if (rs.next()) {
					String userDb = rs.getString("UserName");
					String encryptedPassword = rs.getString("Password");
					String role = rs.getString("Role");

					String decryptedPassword = PasswordEncryptionWIthAes.decryptPassword(encryptedPassword,
							"U3CdwubLD5yQbUOG92ZnHw==");

					if (decryptedPassword != null && userDb.equals(userName) && decryptedPassword.equals(password)
							&& "Admin".equals(role)) {
						return 8;
					} else if (decryptedPassword != null && userDb.equals(userName)
							&& decryptedPassword.equals(password)) {
						return 1; // Login successful
					} else {
						return 0; // Password mismatch
					}
				} else {
					return 0; // No matching record found
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			return -1;
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
			return -1;
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		}
	}

	public UserModel getUserDetails(String userName) {
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(StringUtils.GET_LOGIN_USER_INFO)) {

			statement.setString(1, userName);

			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					UserModel user = new UserModel();
					user.setUserName(resultSet.getString("UserName"));
					return user;
				} else {
					return null;
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			return null;
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public int GET_USER_BY_USERNAME(String username) throws ClassNotFoundException {
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(StringUtils.GET_USER_BY_USERNAME)) {

			statement.setString(1, username);

			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					UserModel user = new UserModel();
					int userid = resultSet.getInt("UserId");

					return userid;
				} else {
					return 0;
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			return 0;
		}
	}

	public int addProduct(ProductModel productModel) {
		try (Connection con = getConnection();
				PreparedStatement st = con.prepareStatement(StringUtils.INSERT_PRODUCT)) {

			st.setString(1, productModel.getProductName());
			st.setString(2, productModel.getDescription());
			st.setDouble(3, productModel.getProductPrice());
			st.setInt(4, productModel.getStockQuantity());
			st.setString(5, productModel.getBrand());
			st.setString(6, productModel.getImage());
			st.setString(7, productModel.getProcessor());
			st.setString(8, productModel.getRam());
			st.setString(9, productModel.getGraphicCard());
			st.setString(10, productModel.getOperatingSystem());
			st.setString(11, productModel.getColor());

			return st.executeUpdate();

		} catch (SQLException ex) {
			ex.printStackTrace();
			return -1;
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
			return -1;
		} catch (Exception ex) {
			ex.printStackTrace();
			return -1;
		}
	}

	public List<ProductModel> getAllProducts() {
		List<ProductModel> products = new ArrayList<>();
		try (Connection con = getConnection();
				PreparedStatement st = con.prepareStatement(StringUtils.GET_ALL_PRODUCTS);
				ResultSet rs = st.executeQuery()) {

			while (rs.next()) {
				ProductModel product = new ProductModel();
				product.setProductId(Integer.parseInt(rs.getString("ProductId")));
				product.setProductName(rs.getString("ProductName"));
				product.setDescription(rs.getString("Description"));
				product.setImage(rs.getString("Image"));
				products.add(product);

				// Print the product data
				System.out.println("Product Name: " + product.getProductName());
				System.out.println("Description: " + product.getDescription());
				System.out.println("IMage: " + product.getImage());
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}
		return products;
	}

	public List<ProductModel> getProductDetails(String productName) {
		List<ProductModel> products = new ArrayList<>();
		try (Connection con = getConnection();
				PreparedStatement st = con.prepareStatement(StringUtils.GET_product_name)) {

			st.setString(1, productName);

			try (ResultSet rs = st.executeQuery()) {
				while (rs.next()) {
					ProductModel product = new ProductModel();
					product.setProductName(rs.getString("ProductName"));
					product.setDescription(rs.getString("Description"));
					product.setStockQuantity(rs.getInt("StockQuantity"));
					product.setProductPrice(rs.getInt("productPrice"));
					product.setImage(rs.getString("Image"));
					product.setBrand(rs.getString("Brand"));
					product.setProcessor(rs.getString("Processor"));
					product.setRam(rs.getString("RAM"));
					product.setGraphicCard(rs.getString("GraphicCard"));
					product.setOperatingSystem(rs.getString("OperatingSystem"));
					product.setColor(rs.getString("Color"));
					products.add(product);

					// Print the product data
					System.out.println("Product Name: " + product.getProductName());
					System.out.println("Description: " + product.getDescription());
					System.out.println("Image: " + product.getImage());
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}
		return products;
	}

	public static boolean addToCartLap(CartModel cart) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			// Establish database connection
			conn = getConnection();

			// Prepare SQL statement
			String sql = StringUtils.INSERT_TO_CART;
			stmt = conn.prepareStatement(sql);

			// Set parameters
			stmt.setInt(1, cart.getQuantity());
			stmt.setInt(2, cart.getUserId());
			stmt.setString(3, cart.getProductId());

			// Execute update
			int rowsAffected = stmt.executeUpdate();

			// Check if any rows were affected
			if (rowsAffected > 0) {
				System.out.println("Item added to cart successfully.");
				return true;
			} else {
				System.out.println("Failed to add item to cart.");
				return false;
			}
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace(); // Log or handle the exception as needed
			return false;
		}

	}

	public List<CartItem> getCartProductDetails(int userId) throws SQLException, ClassNotFoundException {
		List<CartItem> cartProductDetailsList = new ArrayList<>();
		String query = "SELECT cart.CartId, cart.Quantity, cart.AddedDate, users.UserId, product.ProductId, product.ProductName, product.ProductPrice "
				+ "FROM cart " + "INNER JOIN users ON cart.UserId = users.UserId "
				+ "INNER JOIN product ON cart.ProductId = product.ProductId " + "WHERE cart.UserId=?";

		try (Connection con = DatabaseController.getConnection();
				PreparedStatement statement = con.prepareStatement(query)) {
			statement.setInt(1, userId);
			try (ResultSet resultSet = statement.executeQuery()) {
				while (resultSet.next()) {
					// Create a new CartItem object for each row
					CartItem cartProductDetails = new CartItem(resultSet.getInt("ProductId"),
							resultSet.getString("ProductName"), resultSet.getInt("UserId"), resultSet.getInt("CartId"),
							resultSet.getInt("Quantity"), resultSet.getInt("ProductPrice"),
							resultSet.getTimestamp("AddedDate"));
					cartProductDetailsList.add(cartProductDetails);
				}
				return cartProductDetailsList;
			}
		} catch (SQLException e) {
			e.printStackTrace(); // Handle or log the exception as needed
			throw e; // Re-throw the exception to propagate it to the caller
		} catch (ClassNotFoundException e) {
			e.printStackTrace(); // Handle or log the exception as needed
			throw e; // Re-throw the exception to propagate it to the caller
		}
	}

	public ArrayList<CartModel> getproductId() {
		ArrayList<CartModel> carts = new ArrayList<>();

		try (Connection con = getConnection()) {
			String query = "select * from carts c left join product p on c.product_Id = p.product_Id";

			try (PreparedStatement st = con.prepareStatement(query); ResultSet rs = st.executeQuery()) {
				while (rs.next()) {
					CartModel cart = new CartModel();
					cart.setProductId(rs.getString("productId"));
					carts.add(cart);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return carts;
	}

	public static void deleteCartItem(String cartItemId) throws SQLException, ClassNotFoundException {
		// SQL query to delete a cart item by its ID
		String query = "DELETE FROM cart WHERE CartId = ?";

		try (Connection con = getConnection(); PreparedStatement statement = con.prepareStatement(query)) {
			statement.setString(1, cartItemId);
			// Execute the delete query
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace(); // Handle or log the exception as needed
			throw e; // Re-throw the exception to propagate it to the caller
		} catch (ClassNotFoundException e) {
			e.printStackTrace(); // Handle or log the exception as needed
			throw e; // Re-throw the exception to propagate it to the caller
		}
	}

	public int deleteProductInfo(String ProductName) {
		try (Connection con = getConnection()) {
			PreparedStatement st = con.prepareStatement(StringUtils.DELETE_PRODUCT);
			st.setString(1, ProductName);

			int result = st.executeUpdate();
			return result > 0 ? 1 : 0; // Return 1 if deletion is successful, otherwise return 0
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace(); // Log the exception for debugging
			return -1; // Return -1 for any exceptions
		}
	}
}
