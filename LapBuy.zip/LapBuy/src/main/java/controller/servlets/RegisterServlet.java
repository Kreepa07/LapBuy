package controller.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.DatabaseController;
import model.UserModel;
import util.StringUtils;

@WebServlet(asyncSupported = true, urlPatterns = { StringUtils.REGISTER_SERVLET })
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DatabaseController dbController;

    public RegisterServlet() {
        super();
        dbController = new DatabaseController();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter printout = response.getWriter();
        // Printing parameters
       
        String userName = request.getParameter(StringUtils.USER_NAME);
        String email = request.getParameter(StringUtils.EMAIL);
        String phoneNumber = request.getParameter(StringUtils.PHONE_NUMBER);
        String password = request.getParameter(StringUtils.PASSWORD);
        String address = request.getParameter(StringUtils.ADDRESS);
        String retypePassword = request.getParameter(StringUtils.RETYPE_PASSWORD);
        String role = "User";
        
        UserModel userModel = new UserModel(userName, email, password, address, phoneNumber, role);
        int result = dbController.addUser(userModel);
        System.out.println(userModel);

        if (password.equals(retypePassword)) {
            switch (result) {
                case 1:
                    request.setAttribute(StringUtils.SUCCESS_MESSAGE, StringUtils.SUCCESS_REGISTER_MESSAGE);
                    request.getRequestDispatcher(StringUtils.LOGIN_PAGE).forward(request, response);
                    break;
                case -2:
                    request.setAttribute(StringUtils.ERROR_MESSAGE, StringUtils.USERNAME_ERROR_MESSAGE);
                    break;
                case -3:
                    request.setAttribute(StringUtils.ERROR_MESSAGE, StringUtils.EMAIL_ERROR_MESSAGE);
                    break;
                case -4:
                    request.setAttribute(StringUtils.ERROR_MESSAGE, StringUtils.PHONE_NUMBER_ERROR_MESSAGE);
                    break;
                case 0:
                    request.setAttribute(StringUtils.ERROR_MESSAGE, StringUtils.PASSWORD_UNMATCHED_ERROR_MESSAGE);
                    break;
                default:
                    request.setAttribute(StringUtils.ERROR_MESSAGE, StringUtils.SERVER_ERROR_MESSAGE);
                    break;
            }
        } else {
            request.setAttribute(StringUtils.ERROR_MESSAGE, StringUtils.PASSWORD_UNMATCHED_ERROR_MESSAGE);
        }
        request.getRequestDispatcher(StringUtils.REGISTER_PAGE).forward(request, response);
    
    }
}
