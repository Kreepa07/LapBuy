package controller.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;

import controller.DatabaseController;
import model.UserModel;
import util.StringUtils;

@WebServlet(asyncSupported = true, urlPatterns = StringUtils.LOGIN_SERVLET)
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DatabaseController dbController = new DatabaseController();

    public LoginServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userName = request.getParameter("UserName"); // Corrected parameter name
        String password = request.getParameter("password"); // Corrected parameter name

        // Check login credentials
        int loginResult = dbController.getUserLoginInfo(userName, password);

        if (loginResult == 8) {
            // Admin login successful
            HttpSession adminSession = request.getSession();
            adminSession.setAttribute("userName", userName);
            adminSession.setMaxInactiveInterval(30 * 60);

            // Setting admin cookie
            Cookie adminCookie = new Cookie("userName", userName);
            adminCookie.setMaxAge(30 * 60); // Max age in seconds
            response.addCookie(adminCookie);

            // Set admin success message and redirect to admin dashboard
            request.setAttribute(StringUtils.SUCCESS_MESSAGE, "Admin login successful");
            request.getRequestDispatcher(StringUtils.ADMIN_DASHBOARD_PAGE).forward(request, response);
        } else if (loginResult == 1) {
            // Normal user login successful
            HttpSession userSession = request.getSession();
            userSession.setAttribute("userName", userName);
            userSession.setMaxInactiveInterval(30 * 60); // Session lasts for 30 minutes

            // Setting user cookie
            Cookie userCookie = new Cookie("userName", userName);
            userCookie.setMaxAge(30 * 60); // Max age in seconds
            response.addCookie(userCookie);

            // Retrieve user details
            UserModel user = null;
            user = dbController.getUserDetails(userName);

            if (user != null) {
                // Set user details as attributes in the request object
                request.setAttribute("userDetails", user); // Assuming you need user details in the welcome page

                // Set success message and redirect to welcome page
                request.setAttribute(StringUtils.SUCCESS_MESSAGE, StringUtils.SUCCESS_LOGIN_MESSAGE);
                System.out.println("Alish");
                request.getRequestDispatcher(StringUtils.PRODUCT_DISPLAY_SERVLET).forward(request, response);
            } else {
                // If user details are not found, handle the error appropriately
                request.setAttribute(StringUtils.ERROR_MESSAGE, "User details not found");
                request.getRequestDispatcher(StringUtils.LOGIN_PAGE).forward(request, response);
            }
        } else if (loginResult == 0) {
            // Set error message for invalid credentials and forward to login page
            request.setAttribute(StringUtils.ERROR_MESSAGE, StringUtils.ERROR_LOGIN_MESSAGE);
            request.getRequestDispatcher(StringUtils.LOGIN_PAGE).forward(request, response);
        } else {
            // Set server error message and forward to login page
            request.setAttribute(StringUtils.ERROR_MESSAGE, StringUtils.SERVER_ERROR_MESSAGE);
            request.getRequestDispatcher(StringUtils.LOGIN_PAGE).forward(request, response);
        }
    }
}
