package controller.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.List;
import controller.DatabaseController;
import model.CartItem;
import model.CartModel;

@WebServlet("/cartServlet")
public class cartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public cartServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			DatabaseController db = new DatabaseController();
			// Retrieve userId from the session
			HttpSession session = request.getSession();
			String userId = (String) session.getAttribute("userName");
			try {
				int userids = db.GET_USER_BY_USERNAME(userId);
				// Check if userId is not null
				List<CartItem> cartDetailsList = db.getCartProductDetails(userids);

				// Set cart items as an attribute in the request scope
				request.setAttribute("cartItems", cartDetailsList);
				// Forward the request to cart.jsp
				request.getRequestDispatcher("/pages/cart.jsp").forward(request, response);

			} catch (Exception e) {
				e.printStackTrace();
				response.getWriter().println("Failed to fetch cart items");
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().println("Failed to fetch cart items");
		}

	}
}
