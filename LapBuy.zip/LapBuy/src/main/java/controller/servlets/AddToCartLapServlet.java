package controller.servlets;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.DatabaseController;
import model.CartModel;
import util.StringUtils;

@WebServlet("/AddToCartLapServlet")
public class AddToCartLapServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Retrieve parameters from the request
		String productId = request.getParameter("productId");
		String quantityParam = request.getParameter("quantity");

		// Check if productId and quantityParam are not null
		if (productId == null || quantityParam == null) {
			// Handle the error, maybe redirect to an error page
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing productId or quantity parameter");
			return;
		}

		// Parse quantity parameter to integer
		int quantity;
		try {
			quantity = Integer.parseInt(quantityParam);
		} catch (NumberFormatException e) {
			// Handle the parsing error, maybe redirect to an error page
			response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid quantity parameter");
			return;
		}

		// Retrieve userId from the session
		HttpSession session = request.getSession();
		String userId = (String) session.getAttribute("userName");

		DatabaseController db = new DatabaseController();

		try {
			int userids = db.GET_USER_BY_USERNAME(userId);
			System.out.println(userids);
			// Check if userId is not null
			if (userids == 0) {
				// Handle the error, maybe redirect to login page
				response.sendRedirect("login.jsp");
				return;
			}

			// Create CartModel object with price
			CartModel cartObj = new CartModel(productId, userids, quantity);

			// Call AddToCart method with CartModel object
			DatabaseController.addToCartLap(cartObj);
			// Redirect the user to the cart page or any other page
			request.getRequestDispatcher(StringUtils.CART_PAGE).forward(request, response);
		} catch (ClassNotFoundException e) {
			// Handle the ClassNotFoundException, maybe redirect to an error page
			e.printStackTrace();
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
		}
	}
}
