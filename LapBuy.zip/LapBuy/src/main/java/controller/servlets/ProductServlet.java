package controller.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import controller.DatabaseController;
import model.ProductModel;
import util.StringUtils;

@WebServlet(asyncSupported = true, urlPatterns = { StringUtils.PRODUCT_SERVLET })
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 10, // 10MB
maxRequestSize = 1024 * 1024 * 50) // 50MB)

public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    

    private DatabaseController dbController;

    public ProductServlet() {
        super();
        dbController = new DatabaseController();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Printing parameters
        String productName = request.getParameter(StringUtils.PRODUCT_NAME);
        String description = request.getParameter(StringUtils.DESCRIPTION);
        int productPrice = Integer.parseInt(request.getParameter(StringUtils.PRICE));
        int stockQuantity = Integer.parseInt(request.getParameter(StringUtils.QUANTITY));
        String brand = request.getParameter(StringUtils.BRAND);
        Part imagePart = request.getPart(StringUtils.IMAGE);
        String processor = request.getParameter(StringUtils.PROCESSOR);
        String ram = request.getParameter(StringUtils.RAM);
        String graphicCard = request.getParameter(StringUtils.GRAPHIC_CARD);
        String operatingSystem = request.getParameter(StringUtils.OPERATING_SYSTEM);
        String color = request.getParameter(StringUtils.COLOR);

        // Print parameters
        System.out.println("Product Name: " + productName);
        System.out.println("Description: " + description);
        System.out.println("Product Price: " + productPrice);
        System.out.println("Stock Quantity: " + stockQuantity);
        System.out.println("Brand: " + brand);
        System.out.println("Processor: " + processor);
        System.out.println("RAM: " + ram);
        System.out.println("Graphic Card: " + graphicCard);
        System.out.println("Operating System: " + operatingSystem);
        System.out.println("Color: " + color);
        System.out.println("Image: " + imagePart);
        
        // Assuming you have a constructor in ProductModel that accepts all these parameters
        ProductModel productModel = new ProductModel(1,productName, description, productPrice, stockQuantity, brand,imagePart,
                processor, ram, graphicCard, operatingSystem, color);
        int result = dbController.addProduct(productModel);
        String savePath = StringUtils.IMAGE_DIR_PATH;
		String fileName = productModel.getImage();
		
		if (!fileName.isEmpty() && fileName != null) {
			imagePart.write(savePath + fileName);
		}
        
        if (result == 1) {
        	response.sendRedirect(request.getContextPath()+"/AdminProductDisplayServlet");
			/*
			 * request.getRequestDispatcher("/pages/main.jsp").forward(request, response);
			 */
        } else {
            // Error message
            response.setContentType("text/plain");
            PrintWriter out = response.getWriter();
            out.println("Failed to add product!");
        }
    }

}
