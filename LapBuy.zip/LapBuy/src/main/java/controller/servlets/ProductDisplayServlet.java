package controller.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.DatabaseController;
import model.ProductModel;

@WebServlet(asyncSupported = true, urlPatterns = {"/ProductDisplayServlet"})
public class ProductDisplayServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DatabaseController dbController = new DatabaseController();

    public ProductDisplayServlet() {
        super();
    }

    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Fetch all product details from the database
        List<ProductModel> products = dbController.getAllProducts();
        System.out.println("ProductDisplayServlet is hit!");

        System.out.println(products);
        // Set the list of products as an attribute in the request object
        req.setAttribute("products", products);

        // Forward the request to the home.jsp page
        req.getRequestDispatcher("/pages/main.jsp").forward(req, resp);
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Fetch all product details from the database
        List<ProductModel> products = dbController.getAllProducts();
        System.out.println("ProductDisplayServlet is hit!");

        System.out.println(products);
        // Set the list of products as an attribute in the request object
        req.setAttribute("products", products);

        // Forward the request to the home.jsp page
        req.getRequestDispatcher("/pages/main1.jsp").forward(req, resp);
    }
}
